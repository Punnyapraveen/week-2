def is_palindrome(text):
  """
  Checks if a given string is a palindrome (reads the same forwards and backward).

  Args:
    text: The string to check.

  Returns:
    True if the string is a palindrome, False otherwise.
  """
  processed_text = ''.join(filter(str.isalnum, text)).lower()  # Remove non-alphanumeric characters and convert to lowercase
  return processed_text == processed_text[::-1]

# Example usage with the string 'madam'
string_to_check = 'madam'
if is_palindrome(string_to_check):
  print(f"'{string_to_check}' is a palindrome.")
else:
  print(f"'{string_to_check}' is not a palindrome.")


# You can also add a main block to allow running from the command line
if __name__ == "__main__":
  input_string = input("Enter a string to check: ")
  if is_palindrome(input_string):
    print(f"'{input_string}' is a palindrome.")
  else:
    print(f"'{input_string}' is not a palindrome.")