import google.generativeai as genai
import os

# Set your Gemini API key here
GOOGLE_API_KEY = "your_api"
genai.configure(api_key=GOOGLE_API_KEY)

# Create a Gemini model client
model = genai.GenerativeModel("gemini-2.0-flash")  # use the correct model name

# Define agent prompts
def planner_agent(task):
    prompt = f"""You are a travel planner. Create a basic 3-day itinerary for the following task:
{task}
Respond as a structured day-by-day plan."""
    response = model.generate_content(prompt)
    return response.text

def local_agent(plan):
    prompt = f"""You are a local expert. Based on the following travel plan, suggest authentic local activities or cultural experiences in each location. 
Travel plan:
{plan}"""
    response = model.generate_content(prompt)
    return response.text

def language_agent(plan):
    prompt = f"""You are a language advisor. Based on this travel plan, what language or communication tips would you give the traveler in Nepal?
Plan:
{plan}"""
    response = model.generate_content(prompt)
    return response.text

def travel_summary_agent(base_plan, local_tips, lang_tips):
    prompt = f"""You are a travel summarizer. Integrate the following:

1. Base Plan:
{base_plan}

2. Local Tips:
{local_tips}

3. Language Tips:
{lang_tips}

Write a final, integrated, 3-day travel plan with all elements. End with the word TERMINATE."""
    response = model.generate_content(prompt)
    return response.text

# Main function
def main():
    task = "Plan a 3 day trip to Nepal."

    with open("travel_plan.txt", "w", encoding="utf-8") as f:
        f.write("🗺️ Planner Agent:\n")
        base_plan = planner_agent(task)
        f.write(base_plan + "\n\n")

        f.write("🎎 Local Agent:\n")
        local_tips = local_agent(base_plan)
        f.write(local_tips + "\n\n")

        f.write("🗣️ Language Agent:\n")
        lang_tips = language_agent(base_plan)
        f.write(lang_tips + "\n\n")

        f.write("📋 Travel Summary Agent:\n")
        final_plan = travel_summary_agent(base_plan, local_tips, lang_tips)
        f.write(final_plan + "\n")

    print("✅ Travel plan has been saved to 'travel_plan.txt'.")

if __name__ == "__main__":
    main()
