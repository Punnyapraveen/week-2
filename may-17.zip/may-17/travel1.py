import google.generativeai as genai
import os

# Set your Gemini API key here (option 1: directly in code — not safe for production)
GOOGLE_API_KEY = "AIzaSyCp3OhyjXeoHg644fm6_O0ZZ2uf_RtGT1E"  # Replace with your actual Gemini API key
genai.configure(api_key=GOOGLE_API_KEY)

# Create a Gemini model client
model = genai.GenerativeModel("gemini-2.0-flash")

# Define agent prompts
def planner_agent(task):
    prompt = f"""You are a travel planner. Create a basic 3-day itinerary for the following task:
{task}
Respond as a structured day-by-day plan."""
    response = model.generate_content(prompt)
    return response.text

def local_agent(plan):
    prompt = f"""You are a local expert. Based on the following travel plan, suggest authentic local activities or cultural experiences in each location. 
Travel plan:
{plan}"""
    response = model.generate_content(prompt)
    return response.text

def language_agent(plan):
    prompt = f"""You are a language advisor. Based on this travel plan, what language or communication tips would you give the traveler in Nepal?
Plan:
{plan}"""
    response = model.generate_content(prompt)
    return response.text

def travel_summary_agent(base_plan, local_tips, lang_tips):
    prompt = f"""You are a travel summarizer. Integrate the following:

1. Base Plan:
{base_plan}

2. Local Tips:
{local_tips}

3. Language Tips:
{lang_tips}

Write a final, integrated, 3-day travel plan with all elements. End with the word TERMINATE."""
    response = model.generate_content(prompt)
    return response.text

# Main function
def main():
    task = "Plan a 3 day trip to Nepal."

    print("\n🗺️ Planner Agent:")
    base_plan = planner_agent(task)
    print(base_plan)

    print("\n🎎 Local Agent:")
    local_tips = local_agent(base_plan)
    print(local_tips)

    print("\n🗣️ Language Agent:")
    lang_tips = language_agent(base_plan)
    print(lang_tips)

    print("\n📋 Travel Summary Agent:")
    final_plan = travel_summary_agent(base_plan, local_tips, lang_tips)
    print(final_plan)

if __name__ == "__main__":
    main()
